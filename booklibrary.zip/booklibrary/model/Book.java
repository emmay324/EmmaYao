package com.example.booklibrary.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Book {

    private final StringProperty title;
    private final StringProperty author;
    private final StringProperty genre;
    private final IntegerProperty quantity;
    private final IntegerProperty idnum;

    // default constuctor
    public Book() {
        this(null, null, null, 0, 0);
    }

    /**
     * Define constructor for Book
     * @param title
     * @param author
     * @param genre
     * @param idnum
     * @param quantity
     */
    public Book(String title, String author, String genre, Integer idnum, Integer quantity) {
        this.title = new SimpleStringProperty(title);
        this.author = new SimpleStringProperty(author);
        this.genre = new SimpleStringProperty(genre);
        this.quantity = new SimpleIntegerProperty(quantity);
        this.idnum = new SimpleIntegerProperty(idnum);
    }

    /**
     * defind functions for title
     */
    public String getTitle() {
        return title.get();
    }
    public StringProperty titleProperty() {
        return title;
    }

    /**
     * defind functions for author
     */
    public String getAuthor() {
        return author.get();
    }
    public StringProperty authorProperty() {
        return title;
    }

    /**
     * define functions for genre
     */
    public String getGenre() {
        return genre.get();
    }
    public StringProperty genreProperty() {
        return genre;
    }

    /**
     * define functions for id number
     */
    public int getIDNumber() {
        return idnum.get();
    }
    public IntegerProperty idNumProperty() {
        return idnum;
    }

    /**
     * define functions for book quantity
     */
    public int getQuantity() {
        return quantity.get();
    }
    public IntegerProperty quantityProperty() {
        return idnum;
    }


}